import BotaoCustomizado from '../BotaoCustomizado/BotaoCustomizado';
import './Principal.css';

function Principal() {
  return <main className='principal_root'>
    <BotaoCustomizado>Salvar</BotaoCustomizado>
  </main>;
}

export default Principal;
