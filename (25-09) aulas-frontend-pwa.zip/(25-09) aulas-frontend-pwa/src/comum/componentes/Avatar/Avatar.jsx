import "./Avatar.css";
const Avatar = (props) => {

    return <div className="avatar_root">{props.nome}</div>
};

export default Avatar;