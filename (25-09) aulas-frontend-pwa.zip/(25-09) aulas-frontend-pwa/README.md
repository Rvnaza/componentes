## Rodando localmente

Clone o projeto:

```bash
  git clone https://github.com/thiagocordeirooo/aulas-frontend-senai.git
```

Entre no diretório do projeto:

```bash
  cd aulas-frontend-senai
```

Instale as dependências:

```bash
  npm install

  ou 

  npm i
```

Inicie o servidor localmente:

```bash
  npm run dev
```

